/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtin3.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpelazza <mpelazza@student.42nice.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/01 02:11:22 by mpelazza          #+#    #+#             */
/*   Updated: 2023/02/02 07:29:09 by mpelazza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

void	ft_sort_env(t_list *env)
{
	t_list	*tmp;
	void	*swp;

	tmp = env;
	while (tmp->next->next)
	{
		if (ft_strcmp(tmp->content, tmp->next->content) > 0)
		{
			swp = tmp->content;
			tmp->content = tmp->next->content;
			tmp->next->content = swp;
			tmp = env;
		}
		else
			tmp = tmp->next;
	}
}

// copie l'env pour le trier sans changer l'original
// quand c'est trie on imprime on free

void	ft_print_export(t_list *env)
{
	t_list	*env_cpy;
	t_list	*start;
	char	*tmp;
	int		i;

	env_cpy = ft_lstcpy(env);
	start = env_cpy;
	ft_sort_env(env_cpy);
	while (env_cpy->next)
	{
		tmp = (char *)env_cpy->content;
		i = -1;
		while (tmp[++i])
			write(1, &tmp[i], 1);
		if (tmp[i - 1] == '=')
			write(1, "\'\'", 2);
		write(1, "\n", 1);
		env_cpy = env_cpy->next;
	}
	ft_lstfree(&start);
}

// pas au point les checks je reviendai dessus plus tard

int	ft_check_export(t_list *cmd)
{
	char	*tmp;

	while (cmd)
	{
		if (!ft_strcmp((char *)cmd->content, "="))
		{
			ft_put_errors("export: '='", NULL, 0);
			return (0);
		}
		tmp = (char *)cmd->content;
		while (*tmp && *tmp != '=')
			if (ft_isdigit(*tmp++))
				ft_put_errors("export", NULL, 0);
		cmd = cmd->next;
	}
	return (1);
}

void	ft_export(t_list *cmd, t_list *env)
{
	t_list	*tmp;

	if (!cmd)
		ft_print_export(env);
	while (cmd)
	{
		if (!ft_check_export(cmd))
			break ;
		if (!ft_strchr((char *)cmd->content, '='))
			cmd->content
				= (void *)ft_strjoin_free((char *)cmd->content, "=", 1);
		tmp = ft_lstlast(env);
		ft_lstadd_back(&env, ft_lstnew((char *)tmp->content));
		tmp->content = (void *)ft_strdup((char *)cmd->content);
		cmd = cmd->next;
	}
}
