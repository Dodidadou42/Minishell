/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpelazza <mpelazza@student.42nice.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/31 19:35:45 by mpelazza          #+#    #+#             */
/*   Updated: 2023/02/03 05:02:47 by mpelazza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

char	*ft_read_command(char *ret)
{
	if (ret)
		free(ret);
	ret = readline("minishell$> ");
	while (!ret[0])
	{
		free(ret);
		ret = readline("minishell$> ");
	}
	return (ret);
}

void	ft_get_env_var(char *word, char *name, int *index[2], int i[3])
{
	char	*tmp;

	while (name[i[0]] && !ft_strchr("\"\' ", name[i[0]]))
		++i[0];
	i[1] = name[i[0]];
	name[i[0]] = '\0';
	i[2] = ft_strlen(name) - 1;
	name[i[0]] = i[1];
	i[1] = 0;
	while (g_v->env)
	{
		tmp = (char *)g_v->env->content;
		if (!ft_strncmp(&name[1], tmp, i[2]) && tmp[i[2]] == '=')
		{
			i[0] = i[2] + 1;
			while (tmp[i[0]])
				word[i[1]++] = tmp[i[0]++];
			*index[0] += (i[2] + 1);
			*index[1] += i[1];
			return ;
		}
		g_v->env = g_v->env->next;
	}
	*index[0] += (i[2] + 1);
}

void	ft_get_quote(char *word, char *line, int *index[2], char type)
{
	int	i;
	int	j;

	if (!ft_strchr(&line[1], line[0]))
	{
		word[0] = line[0];
		*index[0] += 1;
		*index[1] += 1;
		return ;
	}
	line[ft_find_last_quote(line)] = '\0';
	i = 1;
	j = 0;
	while (line[i])
	{
		if (line[i] == type)
			ft_get_quote(&word[j], &line[i], (int *[]){&i, &j}, type);
		else if (line[i] == '$' && type == '\"')
			ft_get_env_var(&word[j], &line[i], (int *[]){&i, &j},
				(int []){0, 0, 0});
		else
			word[j++] = line[i++];
	}
	*index[0] += (i + 1);
	*index[1] += j;
}

char	*ft_get_word(char *line, int *i)
{
	char	*word;
	int		j;

	word = malloc(sizeof(char) * (ft_word_len(ft_strdup(&line[*i])) + 1));
	j = 0;
	while (line[*i] && line[*i] == ' ')
		++(*i);
	while (line[*i])
	{
		if (line[*i] == '\'' || line[*i] == '\"')
			ft_get_quote(&word[j], &line[*i], (int *[]){i, &j}, line[*i]);
		else if (line[*i] == '$')
			ft_get_env_var(&word[j], &line[*i], (int *[]){i, &j},
				(int []){0, 0, 0});
		else if (line[*i] != ' ')
			word[j++] = line[(*i)++];
		else
			break ;
	}
	word[j] = '\0';
	printf("=> %s\n", word);
	return (word);
}

t_list	*ft_parse_command(char *line)
{
	t_list	*cmd;
	int		i;

	cmd = NULL;
	i = 0;
	while (line[i] && !ft_iswhitespace(line[i]))
		ft_lstadd_back(&cmd, ft_lstnew(ft_get_word(line, &i)));
	return (cmd);
}
