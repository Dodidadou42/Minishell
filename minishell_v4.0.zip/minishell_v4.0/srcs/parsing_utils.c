/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpelazza <mpelazza@student.42nice.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/02 18:59:08 by mpelazza          #+#    #+#             */
/*   Updated: 2023/02/03 11:52:53 by mpelazza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

int	ft_find_last_quote(char *s)
{
	int		i;

	i = 1;
	while (s[i] && s[i] != s[0])
		i++;
	return (i);
}

// LEAKS QUAND UTILISATION VARIABLE ENV
// FAUT COMPTER LES QUOTES LA CON DE SA MERE GENRE '' == " (pour les env var)

int	ft_env_var_len(char *name, int *index)
{
	char	*tmp;
	int		len;
	int		swp;
	int		i;

	i = 0;
	while (name[i] && name[i] != ' ' && name[i] != '\"' && name[i] != '\'')
		++i;
	swp = name[i];
	name[i] = '\0';
	len = ft_strlen(name) - 1;
	name[i] = swp;
	while (g_v->env)
	{
		tmp = (char *)g_v->env->content;
		if (!ft_strncmp(&name[1], tmp, len) && tmp[len] == '=')
		{
			*index += (len + 1);
			return (ft_strlen(tmp) - (len + 1));
		}
		g_v->env = g_v->env->next;
	}
	*index += (len + 1);
	return (0);
}

int	ft_quote_len(char *line, int *index, char type)
{
	int	len;
	int	i;

	if (!ft_strchr(&line[1], line[0]))
	{
		*index += 1;
		return (1);
	}
	line[ft_find_last_quote(line)] = '\0';
	i = 1;
	len = 0;
	while (line[i])
	{
		if (line[i] == type)
			len += ft_quote_len(&line[i], &i, type);
		else if (line[i] == '$' && type == '\"')
			len += ft_env_var_len(&line[i], &i);
		else
		{
			++i;
			++len;
		}
	}
	*index += (i + 1);
	return (len);
}

int	ft_word_len(char *line)
{
	int	len;
	int	i;

	len = 0;
	i = 0;
	while (line[i] && line[i] == ' ')
		++i;
	while (line[i])
	{
		if (line[i] == '\'' || line[i] == '\"')
			len += ft_quote_len(&line[i], &i, line[i]);
		else if (line[i] == '$')
			len += ft_env_var_len(&line[i], &i);
		else if (line[i] != ' ')
		{
			++(i);
			++len;
		}
		else
			break ;
	}
	free(line);
	return (len);
}
