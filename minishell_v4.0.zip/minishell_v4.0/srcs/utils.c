/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpelazza <mpelazza@student.42nice.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/01 16:18:35 by mpelazza          #+#    #+#             */
/*   Updated: 2023/02/03 04:08:23 by mpelazza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

void	ft_put_errors(char *cause, char *details, int is_exit)
{
	ft_putstr_fd("minishell: ", ERROR);
	ft_putstr_fd(cause, ERROR);
	write(ERROR, ": ", 2);
	if (details)
		ft_putstr_fd(details, ERROR);
	else
		ft_putstr_fd(strerror(errno), ERROR);
	write(ERROR, "\n", 1);
	if (is_exit)
		exit(is_exit);
}

char	**ft_list_to_string_tab(t_list *lst)
{
	char	**tab;
	int		i;

	tab = malloc(sizeof(char *) * (ft_lstsize(lst) + 1));
	i = 0;
	while (lst)
	{
		tab[i++] = ft_strdup((char *)lst->content);
		lst = lst->next;
	}
	tab[i] = NULL;
	return (tab);
}
