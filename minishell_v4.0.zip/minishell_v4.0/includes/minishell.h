/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpelazza <mpelazza@student.42nice.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/31 16:54:48 by mpelazza          #+#    #+#             */
/*   Updated: 2023/02/03 04:51:29 by mpelazza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include <stdlib.h>
# include <unistd.h>
# include <string.h>
# include <stdio.h>
# include <sys/wait.h>
# include <fcntl.h>
# include <readline/readline.h>
# include <readline/history.h>
# include <errno.h>
# include <signal.h>
# include "libft/libft.h"

# define ERROR 2

typedef struct s_var
{
	t_list	*env;
	t_list	*cmd;

	pid_t	process;

	char	**path;
	char	*line;
}				t_var;
//t_list	**pipe_cmd; //pour stocker les commandes a faire dans chaque pipe
// faudra gerer ca avant de lancer ft_builtin

t_var	*g_v;

//parsing
char	*ft_read_command(char *ret);
t_list	*ft_parse_command(char *line);
//parsin_tools
int		ft_find_last_quote(char *s);
void	ft_env_swap(int *i, int *j, int *len, char *name);
int		ft_env_var_len(char *name, int *index);
int		ft_quote_len(char *line, int *index, char type);
int		ft_word_len(char *line);
//builtin
int		ft_builtin(t_list *cmd, t_list *env);
void	ft_echo(t_list *cmd);
void	ft_pwd(void);
void	ft_export(t_list *cmd, t_list *env);
void	ft_unset(t_list *cmd, t_list *env);
void	ft_env(t_list *env);
//execution
//
//signal
void	ft_sig_handler(int signal);
//utils
void	ft_put_errors(char *cause, char *details, int is_exit);
char	**ft_list_to_string_tab(t_list *lst);

#endif