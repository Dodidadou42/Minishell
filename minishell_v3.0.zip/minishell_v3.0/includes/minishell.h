/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpelazza <mpelazza@student.42nice.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/31 16:54:48 by mpelazza          #+#    #+#             */
/*   Updated: 2023/02/02 07:02:02 by mpelazza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include <stdlib.h>
# include <unistd.h>
# include <string.h>
# include <stdio.h>
# include <sys/wait.h>
# include <fcntl.h>
# include <readline/readline.h>
# include <readline/history.h>
# include <errno.h>
# include <signal.h>
# include "libft/libft.h"

# define ERROR 2

typedef struct s_var
{
	t_list	*env;
	t_list	*cmd;

	pid_t	process;

	char	**path;
	char	*line;
}				t_var;
//t_list	**pipe_cmd; //pour stocker les commandes a faire dans chaque pipe
// faudra gerer ca avant de lancer ft_builtin

//variable globale // pas besoin pour ctrl-C si ca marche avec rl_replace_line
//t_var	*v;

//parsing
char	*ft_read_command(char *ret);
t_list	*ft_parse_command(t_list *env, char *line);
//env_var
char	*ft_get_env_var(char *name, t_list *env);
char	*ft_handle_env_var(t_list *env, char *word, char *ret, int i[3]);
//
//builtin
int		ft_builtin(t_list *cmd, t_list *env);
void	ft_echo(t_list *cmd);
void	ft_pwd(void);
void	ft_export(t_list *cmd, t_list *env);
void	ft_unset(t_list *cmd, t_list *env);
void	ft_env(t_list *env);
//execution
//signal
void	ft_sig_handler(int signal);
//utils
void	ft_put_errors(char *cause, char *details, int is_exit);
char	**ft_list_to_string_tab(t_list *lst);
int		ft_find_last_quote(char *s);
int		ft_check_dquote(char *s, int *i);

#endif