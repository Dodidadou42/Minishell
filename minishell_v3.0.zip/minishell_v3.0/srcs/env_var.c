/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   env_var.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpelazza <mpelazza@student.42nice.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/02 04:52:00 by mpelazza          #+#    #+#             */
/*   Updated: 2023/02/02 07:20:42 by mpelazza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

char	*ft_get_env_var(char *name, t_list *env)
{
	int		len;
	int		i;

	len = ft_strlen(name) - 1;
	i = 0;
	while (env)
	{
		if (!ft_strncmp(&name[1], (char *)env->content, len))
			return (ft_strdup((char *)&env->content[len + 1]));
		env = env->next;
	}
	return (ft_strdup(""));
}

int	ft_env_var_len(t_list *env, char *word, char *tmp, int len)
{
	int		i;

	len = 0;
	i = 0;
	while (word[i])
	{
		if (word[i] == '\'' && ft_find_last_quote(&word[i]))
		{
			len += ft_strlen(&word[i]) - ft_find_last_quote(&word[i]);
			i += len + 2;
		}
		else if (word[i] == '$')
		{
			tmp = ft_get_env_var(&word[i], env);
			len += ft_strlen(tmp);
			free(tmp);
			break ;
		}
		else if (word[i] && !ft_check_dquote(word, &i))
		{
			++len;
			++i;
		}
	}
	return (len);
}

// Enleve les quotes des cmd quand elles sont par deux et va chercher les
// variables environnemental 
// fonctionne avec la fonction de parsing (ft_get_word)
// donc on fait ca avant de lancer les commandes c'est super 

char	*ft_handle_env_var(t_list *env, char *word, char *tmp, int i[3])
{
	char	*ret;

	ret = malloc(sizeof(char) * (ft_env_var_len(env, word, NULL, 0) + 1));
	while (word[i[0]])
	{
		if (word[i[0]] == '\'' && ft_find_last_quote(&word[i[0]]))
		{
			while (word[++i[0]] != '\'')
				ret[i[1]++] = word[i[0]];
			++i[0];
		}
		else if (word[i[0]] == '$')
		{
			tmp = ft_get_env_var(&word[i[0]], env);
			while (tmp[i[2]])
				ret[i[1]++] = tmp[i[2]++];
			free(tmp);
			break ;
		}
		else if (word[i[0]] && !ft_check_dquote(word, &i[0]))
			ret[i[1]++] = word[i[0]++];
	}
	ret[i[1]] = '\0';
	free(word);
	return (ret);
}
