/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtin1.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpelazza <mpelazza@student.42nice.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/01 01:35:48 by mpelazza          #+#    #+#             */
/*   Updated: 2023/02/02 07:34:49 by mpelazza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

int	ft_builtin(t_list *cmd, t_list *env)
{
	if (!ft_strcmp((char *)cmd->content, "echo"))
		ft_echo(cmd->next);
	else if (!ft_strcmp((char *)cmd->content, "pwd"))
		ft_pwd();
	else if (!ft_strcmp((char *)cmd->content, "export"))
		ft_export(cmd->next, env);
	else if (!ft_strcmp((char *)cmd->content, "unset"))
		ft_unset(cmd->next, env);
	else if (!ft_strcmp((char *)cmd->content, "env"))
		ft_env(env);
	else if (!ft_strcmp((char *)cmd->content, "exit"))
	{
		system("leaks minishell");
		exit(0);
	}
	else
		return (0);
	return (1);
}

// manque plus que cd va falloir lire de la doc :-)

void	ft_echo(t_list *cmd)
{
	t_list	*tmp;
	char	*cast;
	int		nl;

	tmp = cmd;
	nl = 1;
	if (!ft_strcmp((char *)tmp->content, "-n"))
	{
		nl = 0;
		tmp = tmp->next;
	}
	while (tmp)
	{
		cast = (char *)tmp->content;
		ft_putstr_fd(cast, 1);
		if (tmp->next && cast[0])
			ft_putchar_fd(' ', 1);
		tmp = tmp->next;
	}
	if (nl)
		ft_putchar_fd('\n', 1);
}

void	ft_pwd(void)
{
	char	*pwd;

	pwd = getcwd(NULL, 0);
	printf("%s\n", pwd);
	free(pwd);
}

void	ft_unset(t_list *cmd, t_list *env)
{
	t_list	*prev;
	char	*tmp;
	int		len;

	tmp = ft_strjoin((char *)cmd->content, "=");
	len = ft_strlen(tmp);
	while (env && ft_strncmp(tmp, (char *)env->content, len))
	{
		prev = env;
		env = env->next;
	}
	free(tmp);
	if (env)
	{
		prev->next = prev->next->next;
		free(env->content);
		free(env);
	}
}

void	ft_env(t_list *env)
{
	while (env)
	{
		printf("%s\n", (char *)env->content);
		env = env->next;
	}
}
