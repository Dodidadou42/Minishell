/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpelazza <mpelazza@student.42nice.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/31 19:35:45 by mpelazza          #+#    #+#             */
/*   Updated: 2023/02/02 07:23:24 by mpelazza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

char	*ft_read_command(char *ret)
{
	if (ret)
		free(ret);
	ret = readline("minishell$> ");
	while (!ret[0])
	{
		free(ret);
		ret = readline("minishell$> ");
	}
	return (ret);
}

int	ft_word_len(char *cmd, int i)
{
	int	len;
	int	j;

	len = 0;
	while (cmd[i] && cmd[i] == ' ')
			++i;
	while (cmd[i] && cmd[i] != ' ')
	{
		if (cmd[i] == '\'' || cmd[i] == '\"')
		{
			j = ft_strlen(cmd) - 1;
			while (j > i + 1 && cmd[j] != cmd[i])
				--j;
			if (cmd[j] && cmd[j] == cmd[i])
			{
				len += (j - i);
				i = j;
			}
		}
		++i;
		++len;
	}
	return (len);
}

// Recupere le mot en gerant les espaces 
// mais en incluant les quotes 
//puis le passe a une fonction qui gere les quote et les var env.
// tu remarquera plein de technique de rat pour la norme 

char	*ft_get_word(t_list *env, char *cmd, int *i, int k)
{
	char	*word;
	int		j;

	word = malloc(sizeof(char) * (ft_word_len(cmd, *i) + 1));
	while (cmd[*i] && cmd[*i] == ' ')
			++(*i);
	while (cmd[*i] && cmd[*i] != ' ')
	{
		if (cmd[*i] == '\'' || cmd[*i] == '\"')
		{
			j = ft_strlen(cmd) - 1;
			while (j > *i + 1 && cmd[j] != cmd[*i])
				--j;
			if (cmd[j] && cmd[j] == cmd[*i])
				while (*i < j)
					word[k++] = cmd[(*i)++];
		}
		if (cmd[*i] && cmd[*i] != ' ')
			word[k++] = cmd[(*i)++];
	}
	word[k] = '\0';
	word = ft_handle_env_var(env, word, NULL, (int [3]){0, 0, 0});
	return (word);
}

t_list	*ft_parse_command(t_list *env, char *line)
{
	t_list	*cmd;
	int		i;

	cmd = NULL;
	i = 0;
	while (line[i])
		ft_lstadd_back(&cmd, ft_lstnew(ft_get_word(env, line, &i, 0)));
	return (cmd);
}
