/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpelazza <mpelazza@student.42nice.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/31 16:56:29 by mpelazza          #+#    #+#             */
/*   Updated: 2023/02/02 07:12:39 by mpelazza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

t_var	*ft_init_var(char **envp)
{
	t_var	*var;
	int		i;

	if (!envp[0])
	{
		envp[0] = "PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin";
		envp[1] = NULL;
	}
	var = malloc(sizeof(t_var));
	var->env = NULL;
	i = -1;
	while (envp[++i])
		ft_lstadd_back(&var->env, ft_lstnew(ft_strdup(envp[i])));
	var->path = ft_split(getenv("PATH"), ':');
	var->line = NULL;
	return (var);
}

int	main(int argc, char **argv, char **envp)
{
	t_var	*v;

	(void)argc;
	(void)argv;
	v = ft_init_var(envp);
	signal(SIGINT, ft_sig_handler);
	while (1)
	{
		v->line = ft_read_command(v->line);
		v->cmd = ft_parse_command(v->env, v->line);
		ft_builtin(v->cmd, v->env);
		ft_lstfree_content(&v->cmd);
	}
	return (0);
}

// signal c'est pour intercepter les ctrl-* mais ca marche pas encore

// j'ai passe env en list et cmd aussi enfin en liste classique (comme faut 
//   plus gerer quote seul) pour utiliser les fonctions de lib pepere
// env en liste pour ajouter et enlever des elements facilement (export / unset)

// ft_builtin renvoie un 1 si elle a detecter et excecuter un builtin 0 sinon
//	pour savoir si on part dans les process ou pas

//pas de leak quand on free pas surement la theorie de mathis
//(faut tester les leaks avant exit dans builtin pas dans le main)

/*printage de var
	printf("PATH=");
	for (int i = 0; v->path[i]; i++)
		printf("%s:", v->path[i]);
	printf("\n\nenv :\n");
	t_list	*tmp = v->env;
	while (tmp)
	{
		printf("%s\n", (char *)tmp->content);
		tmp = tmp->next;
	}*/

/*printage cmd
	t_list	*tmp = v->cmd;
	while (tmp)
	{
		printf("%s\n", (char *)tmp->content);
		tmp = tmp->next;
	}*/